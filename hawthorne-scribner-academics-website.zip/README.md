# Hawthorne Scribner High School Academics

Public academic website for Hawthorne Scribner High School.

## Pages
- Home
- Departments
- Programs
- Faculty
- Calendar
- Resources
- Contact

## Deploy
This is a static site. Vercel should publish automatically from the `main` branch.
