const btn = document.querySelector(".menu-btn");
const links = document.querySelector(".nav-links");
if (btn && links) {
  btn.addEventListener("click", () => links.classList.toggle("open"));
}

document.querySelectorAll("[data-count]").forEach((el) => {
  const target = Number(el.dataset.count);
  let n = 0;
  const step = Math.max(1, Math.floor(target / 60));
  const tick = () => {
    n = Math.min(target, n + step);
    el.textContent = n.toLocaleString();
    if (n < target) requestAnimationFrame(tick);
  };
  tick();
});
